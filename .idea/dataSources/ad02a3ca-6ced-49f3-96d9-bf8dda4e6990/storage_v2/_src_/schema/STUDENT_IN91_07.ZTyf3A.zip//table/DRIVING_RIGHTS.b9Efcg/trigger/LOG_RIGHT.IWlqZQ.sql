create trigger LOG_RIGHT
    after insert or update of PERSON_ID,START_DATE or delete
    on DRIVING_RIGHTS
    for each row
begin
    if inserting
        then insert into Right_Log values (L_SEQ.nextval,:new.person_id,:new.transport_id,:new.dright,:new.start_date,null);
    elsif deleting
        then update Right_Log set end_date=systimestamp where Right_Log.person_id=:old.person_id and Right_Log.transport_id=:old.transport_id;
    elsif updating then
        update Right_Log set end_date=systimestamp where Right_Log.person_id=:old.person_id and Right_Log.transport_id=:old.transport_id;
        insert into Right_Log values (L_SEQ.nextval,:new.person_id,:old.transport_id,:old.dright,:new.start_date,null);
    end if;
end;
/

