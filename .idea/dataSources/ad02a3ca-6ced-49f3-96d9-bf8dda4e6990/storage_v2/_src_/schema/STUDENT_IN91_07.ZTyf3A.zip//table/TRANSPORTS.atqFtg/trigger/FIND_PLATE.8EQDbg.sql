create trigger FIND_PLATE
    after insert or update of LICENSE_PLATE
    on TRANSPORTS
    for each row
begin
    delete from Lost_Plates where Lost_Plates.license_plate=:new.license_plate;
end;
/

