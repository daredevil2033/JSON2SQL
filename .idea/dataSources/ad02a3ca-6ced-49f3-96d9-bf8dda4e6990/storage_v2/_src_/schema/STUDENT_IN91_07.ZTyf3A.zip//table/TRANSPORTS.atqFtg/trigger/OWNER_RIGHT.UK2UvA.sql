create trigger OWNER_RIGHT
    after insert or update of OWNER_ID
    on TRANSPORTS
    for each row
begin
    if inserting
        then insert into Driving_Rights values (:new.owner_id,:new.transport_id,'owner',systimestamp);
    elsif updating
        then update Driving_Rights set Driving_Rights.person_id=:new.owner_id, Driving_Rights.start_date=systimestamp where Driving_Rights.transport_id=:old.transport_id;
    end if;
end;
/

