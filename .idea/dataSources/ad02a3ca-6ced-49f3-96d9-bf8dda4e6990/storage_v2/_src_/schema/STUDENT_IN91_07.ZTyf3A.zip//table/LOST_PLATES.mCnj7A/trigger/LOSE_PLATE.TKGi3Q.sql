create trigger LOSE_PLATE
    before insert
    on LOST_PLATES
    for each row
begin
    update Transports set license_plate=(select * from
        (select license_plate from License_Plates
         minus
         select license_plate from Transports
         minus
         select license_plate from Lost_Plates)
                                         where rownum=1)
    where Transports.license_plate=:new.license_plate;
end;
/

